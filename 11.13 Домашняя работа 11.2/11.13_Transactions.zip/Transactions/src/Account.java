public class Account
{
    private long money;
    private String accNumber;
}
