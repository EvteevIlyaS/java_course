package binary_tree;

import java.util.List;

public class BinaryTree
{
    private Node root;

    public void addNode(String data)
    {
        //TODO
    }

    public List<Node> searchNodes(String data)
    {
        //TODO
        return null;
    }
}