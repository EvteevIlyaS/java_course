package binary_tree;

public class Node
{
    private String data;

    private Node parent;
    private Node left;
    private Node right;

    //TODO: create and implement methods
}