package double_linked_list;

public class DoubleLinkedList
{
    private ListItem head;
    private ListItem tail;

    public ListItem getHeadElement()
    {
        return head;
    }

    public ListItem getTailElement()
    {
        return tail;
    }

    public ListItem popHeadElement()
    {
        //TODO
        return null;
    }

    public ListItem popTailElement()
    {
        //TODO
        return null;
    }

    public void removeHeadElement()
    {
        //TODO
    }

    public void removeTailElement()
    {
        //TODO
    }

    public void addToHead(ListItem item)
    {
        //TODO
    }

    public void addToTail(ListItem item)
    {
        //TODO
    }
}