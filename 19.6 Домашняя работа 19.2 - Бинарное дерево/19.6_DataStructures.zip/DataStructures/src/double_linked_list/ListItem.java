package double_linked_list;

public class ListItem
{
    private String data;
    private ListItem prev;
    private ListItem next;
}